import logging
import subprocess
import sys
import os
import re
import time
import concurrent.futures
import discord
from discord.ext import commands, tasks
import docker

TOKEN = 'MTI0OTg1NjYxODQ2ODczNzEwNA.G36Yna.X_EvVEq0Z_XsFoT0bb_dQtgsj50dhkiVd7yT7Y'
RAM_LIMIT = '2g'

intents = discord.Intents.default()
intents.messages = False
intents.message_content = False

bot = commands.Bot(command_prefix='/', intents=intents)

client = docker.from_env()

SERVER_LIMIT = 12
database_file = 'database.txt'

executor = concurrent.futures.ThreadPoolExecutor(max_workers=150)

def add_to_database(user, container_name, ssh_command):
    with open(database_file, 'a') as f:
        f.write(f"{user}|{container_name}|{ssh_command}\n")

def remove_from_database(ssh_command):
    if not os.path.exists(database_file):
        return
    with open(database_file, 'r') as f:
        lines = f.readlines()
    with open(database_file, 'w') as f:
        for line in lines:
            if ssh_command not in line:
                f.write(line)

def get_user_servers(user):
    if not os.path.exists(database_file):
        return []
    servers = []
    with open(database_file, 'r') as f:
        for line in f:
            if line.startswith(user):
                servers.append(line.strip())
    return servers

def count_user_servers(user):
    return len(get_user_servers(user))

@bot.event
async def on_ready():
    change_status.start()
    print(f'Bot is ready. Logged in as {bot.user}')
    await bot.tree.sync()

@tasks.loop(minutes=1)
async def change_status():
    await bot.change_presence(activity=discord.Game(name="with Cloud Instances"))

@bot.tree.command(name="list", description="Lists all your Instances")
async def list_servers(interaction: discord.Interaction):
    user = str(interaction.user)
    servers = get_user_servers(user)
    if servers:
        embed = discord.Embed(title="Your Instances", color=0x00ff00)
        for server in servers:
            _, container_name, _ = server.split('|')
            embed.add_field(name=container_name, value="Description: a Instance with 24GB RAM and 8cores.", inline=False)
        await interaction.response.send_message(embed=embed)
    else:
        await interaction.response.send_message(embed=discord.Embed(description="You have no servers.", color=0xff0000))

@bot.tree.command(name="help", description="Shows the help message")
async def help_command(interaction: discord.Interaction):
    embed = discord.Embed(title="Help", color=0x00ff00)
    embed.add_field(name="/deploy-ubuntu", value="Creates a new Instance with Ubuntu 22.04.", inline=False)
    embed.add_field(name="/deploy-debian", value="Creates a new Instance with Debian 12.", inline=False)
    embed.add_field(name="/remove <ssh_command/Name>", value="Removes a server", inline=False)
    embed.add_field(name="/start <ssh_command/Name>", value="Start a server.", inline=False)
    embed.add_field(name="/stop <ssh_command/Name>", value="Stop a server.", inline=False)
    embed.add_field(name="/list", value="List all your server", inline=False)
    await interaction.response.send_message(embed=embed)

async def get_ssh_session_line(container):
    def get_ssh_session(logs):
        match = re.search(r'ssh session: (ssh [^\n]+)', logs)
        if match and "ro-" not in match.group(1):
            return match.group(1)
        return None

    ssh_session_line = None
    max_attempts = 5000
    attempt = 0

    while attempt < max_attempts:
        logs = container.logs().decode('utf-8')
        ssh_session_line = get_ssh_session(logs)
        if ssh_session_line:
            break
        attempt += 1

    return ssh_session_line

async def create_server_task(interaction: discord.Interaction):
    await interaction.response.send_message(embed=discord.Embed(description="Creating Instance, This takes a few seconds.", color=0x00ff00))
    user = str(interaction.user)
    if count_user_servers(user) >= SERVER_LIMIT:
        await interaction.followup.send(embed=discord.Embed(description="```Error: Instance Limit-reached```", color=0xff0000))
        return

    image = "ubuntu-22.04-with-tmate"

    container = client.containers.run(
        image,
        command="tmate -F",
        detach=True,
        tty=True,
        privileged=True,
    )

    container_id = container.id  # Get the container ID

    # Execute tmate -F inside the container
    try:
        exec_command = f"tmate -F"
        exec_result = container.exec_run(exec_command)
        exec_output = exec_result.output.decode('utf-8').strip()
        
        # Parse the SSH session line from the output if available
        ssh_session_line = get_ssh_session(exec_output)
        
        if ssh_session_line:
            await interaction.user.send(embed=discord.Embed(description=f"### Successfully created Instance\n SSH Session Command: ```{ssh_session_line}```OS: Ubuntu 22.04", color=0x00ff00))
            add_to_database(user, container.name, ssh_session_line)
            await interaction.followup.send(embed=discord.Embed(description="Instance created successfully. Check your DMs for details.", color=0x00ff00))
        else:
            await interaction.followup.send(embed=discord.Embed(description="Something went wrong or the Instance is taking longer than expected. if this problem continues, Contact Support.", color=0xff0000))
    except Exception as e:
        logging.error(f"Error executing command inside container: {e}")
        await interaction.followup.send(embed=discord.Embed(description="Error executing command inside container. Please contact support.", color=0xff0000))
        if container.status == 'running':
            container.kill()
        container.remove()

@bot.tree.command(name="deploy-ubuntu", description="Creates a new Instance with Ubuntu 22.04")
async def deploy_ubuntu(interaction: discord.Interaction):
    await create_server_task(interaction)

@bot.tree.command(name="remove", description="Removes a Instance")
async def remove(interaction: discord.Interaction, ssh_command: str):
    await remove_server_task(interaction, ssh_command)

async def remove_server_task(interaction: discord.Interaction, ssh_command: str):
    user = str(interaction.user)
    servers = get_user_servers(user)
    if any(ssh_command in server for server in servers):
        container_name = next((server.split('|')[1] for server in servers if ssh_command in server), None)
        if container_name:
            container = client.containers.get(container_name)
            if container.status == 'running':
                container.kill()
            container.remove()
            remove_from_database(ssh_command)
            await interaction.response.send_message(embed=discord.Embed(description="Server removed successfully.", color=0x00ff00))
        else:
            await interaction.response.send_message(embed=discord.Embed(description="Server not found.", color=0xff0000))
    else:
        await interaction.response.send_message(embed=discord.Embed(description="Something went wrong trying to delete this server.", color=0xff0000))

bot.run(TOKEN)
