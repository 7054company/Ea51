import subprocess
import asyncio

async def create_server():
    image = "ubuntu-22.04-with-tmate"

    try:
        container_id = subprocess.check_output([
            "docker", "run", "-itd", "--privileged", "--cap-add=ALL", image
        ]).strip().decode('utf-8')
        #print(f"Container created with ID: {container_id}")
    except subprocess.CalledProcessError as e:
        #print(f"Error creating Docker container: {e}")
        return

    try:
        exec_cmd = await asyncio.create_subprocess_exec("docker", "exec", container_id, "tmate", "-F",
                                                        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        #print("Executing tmate -F in Docker container...")
    except subprocess.CalledProcessError as e:
        #print(f"Error executing tmate in Docker container: {e}")
        subprocess.run(["docker", "kill", container_id])
        subprocess.run(["docker", "rm", container_id])
        return

    ssh_session_line = await capture_ssh_session_line(exec_cmd)
    if ssh_session_line:
        print(f"SSH Session Command: {ssh_session_line}")
    else:
        #print("Something went wrong or the Instance is taking longer than expected.")
        subprocess.run(["docker", "kill", container_id])
        subprocess.run(["docker", "rm", container_id])

async def capture_ssh_session_line(exec_cmd):
    while True:
        line = await exec_cmd.stdout.readline()
        if line:
            line = line.decode('utf-8').strip()
            if "ssh session:" in line.lower():
                return line.split("ssh session:")[1].strip()
        else:
            break
    return None

async def main():
    tasks = [create_server() for _ in range(10)]
    await asyncio.gather(*tasks)

if __name__ == "__main__":
    asyncio.run(main())
